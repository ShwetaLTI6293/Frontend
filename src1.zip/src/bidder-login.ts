import {Component} from '@angular/core'

export class BidderLogin{

    constructor(
        public emailId?:string,
        public password?:string,
        
         ){

         }
}