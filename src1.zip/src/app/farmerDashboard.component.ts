import { Component } from '@angular/core';


@Component({
    selector: 'farmerDashboard',
    templateUrl: './farmerDashboard.component.html',
    styleUrls: ['./farmerDashboard.component.css']

    
})

export class FarmerDashboard{
    constructor(){

    }
    
}