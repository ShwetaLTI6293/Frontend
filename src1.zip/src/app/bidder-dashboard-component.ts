import {Component} from '@angular/core'
//importing product class

//this gets imported when we implement OnInit
import { OnInit } from '@angular/core';
import { BidderDashboardService } from './bidder-dashboard-service';
import { BidderDashboard } from './bidder-dashboard';
@Component({
    selector: 'bidder-dashboard',
    templateUrl: './bidder-dashboard-component.html'
})

export class BidderDashboardComponent implements OnInit{
    dashboard: BidderDashboard[];
    constructor(private bds: BidderDashboardService){

    }
    ngOnInit(){
        this.loadProducts();
     }
    loadProducts()
    {
        let url = "http://localhost:8150/bidder/biddingcrop";
        this.bds.retrieveFromServer(url).subscribe(data=>{
            this.dashboard=data;
            console.log(this.dashboard);
        });
        
    }
  
}
