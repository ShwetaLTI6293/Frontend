import { Bidder } from './bidder';
import { Component } from '@angular/core';
import { BidderService } from './bidder-service';
@Component({
selector :'add-bidder',
templateUrl:'./bidder-component.html',
//styleUrls: ['../css/mdb.min.css', '../css/bootstrap.min.css']
})

export class BidderComponent{
    bidder: Bidder = new Bidder();
    response: string;
    confirmpass:String;
    array={ password:"" , msg: ""};
    constructor(private ms: BidderService){

    }

    keyPress(event: any) {
        const pattern = /[0-9\+\-\ ]/;
        let inputChar = String.fromCharCode(event.charCode);
        if (event.keyCode != 8 && !pattern.test(inputChar)) {
          event.preventDefault();
        }
      }

     /*(keypress)="keyPress($event)"
     {

        if (this.confirmpass != this.bidder.password) {
            confirm = false;
            this.array['password'] = "Pasword does not match";
        }
    }*/
   add(mform){
    let confirm=true;

    if(this.confirmpass != this.bidder.password){
        confirm=false;
        this.array['password'] = "Password does not match";
    }
   if(confirm){
    
        this.ms.sendToServer(this.bidder).subscribe(
            data => {
                //Take the response from server and storing in string variable
                this.response = data['status'];
            }
        );
    } 

   

}
}